/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'lt', {
	button: 'Šablonai',
	emptyListMsg: '(Šablonų sąrašas tuščias)',
	insertOption: 'Pakeisti dabartinį turinį pasirinktu šablonu',
	options: 'Template Options',
	selectPromptMsg: 'Pasirinkite norimą šabloną<br>(<b>Dėmesio!</b> esamas turinys bus prarastas):',
	title: 'Turinio šablonai'
} );

/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'zh', {
	button: '範本',
	emptyListMsg: '(尚未定義任何範本)',
	insertOption: '替代實際內容',
	options: '範本選項',
	selectPromptMsg: '請選擇要在編輯器中開啟的範本。',
	title: '內容範本'
} );

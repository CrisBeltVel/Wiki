/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'fi', {
	button: 'Pohjat',
	emptyListMsg: '(Ei määriteltyjä pohjia)',
	insertOption: 'Korvaa koko sisältö',
	options: 'Sisältöpohjan ominaisuudet',
	selectPromptMsg: 'Valitse editoriin avattava pohja',
	title: 'Sisältöpohjat'
} );

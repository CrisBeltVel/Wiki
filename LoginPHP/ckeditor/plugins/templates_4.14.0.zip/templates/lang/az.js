/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'az', {
	button: 'Şablon',
	emptyListMsg: '(Heç bir şablon təyin edilməyib)',
	insertOption: 'Həqiqi içindəkiləri əvəz et',
	options: 'Şablonun seçimləri',
	selectPromptMsg: 'Redaktor ilə açmaq üçün şablonu seçin',
	title: 'İçindəkinin şablonu'
} );
